<?php
$con = mysqli_connect('localhost', 'root', '', 'matrix_operations') or die("Connection Error: " . mysqli_error($con));
?>
