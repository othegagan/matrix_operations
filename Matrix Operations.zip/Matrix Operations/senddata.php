<?php

require"db_connection.php";

$add_count =  $_POST['add_count'];
$sub_count =  $_POST['sub_count'];
$mult_count =  $_POST['mult_count'];
$swap_count =  $_POST['swap_count'];
$inverse_count = $_POST['inverse_count'];
$transpose_count = $_POST["transpose_count"];
$power_count = $_POST["power_count"];
$determinant_count = $_POST["determinant_count"];
$multiple_number_count = $_POST["multiple_number_count"];


// to fetch all last record
$data = mysqli_query($con,"select *from statistics ORDER BY statistics_id DESC LIMIT 1;");
$rowData = mysqli_fetch_array($data);

$addition = (int)$rowData['addition'] + (int)$add_count;
$subtraction = (int)$rowData['subtraction'] + (int)$sub_count;
$multiplication = (int)$rowData['multiplication'] + (int)$mult_count;
$swap = (int)$rowData['swap'] + (int)$swap_count;
$inverse = (int)$rowData['inverse'] + (int)$inverse_count;
$transpose = (int)$rowData['transpose'] + (int)$transpose_count;
$power = (int)$rowData['power'] + (int)$power_count;
$determinant = (int)$rowData['determinant'] + (int)$determinant_count;
$multiple_number = (int)$rowData['multiple_number'] + (int)$multiple_number_count;

$updadte = mysqli_query($con,"UPDATE `statistics` SET `addition`= $addition, `subtraction`= $subtraction, `multiplication`= $multiplication,`swap`=$swap,`inverse`=$inverse, `transpose`=$transpose, `power`=$power, `determinant`=$determinant, `multiple_number`=$multiple_number  ");

if ($update) {
    echo "data updated";
}else{
    echo "problem";
}

mysqli_close($con);


