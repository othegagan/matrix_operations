<?php
require "db_connection.php";

if (isset($_POST["submit"])) {
    $name = mysqli_real_escape_string($con, $_POST["name"]);
    $email = mysqli_real_escape_string($con, $_POST["email"]);
    $feedback = mysqli_real_escape_string($con, $_POST["feedback"]);

    $query = "INSERT INTO `feedback`(`name`, `email`, `feedback`) VALUES ('$name', '$email', '$feedback')";

    $insert_query = mysqli_query($con, $query);

    if ($insert_query) {?>
        <script>
            alert("Thank you for your feedback");
        </script>
    <?php header("Refresh:1");
    } else {
    ?>
        <script>
            alert("Oops! Something went wrong while submitting ..!")
        </script>
<?php }
}
mysqli_close($con);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Project Matrix | Home</title>
    <meta content="matrix home" property="og:title" />
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <link rel="stylesheet" href="style.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js" type="text/javascript"></script>
    <script type="text/javascript">
        WebFont.load({
            google: {
                families: [
                    "Poppins:200,300,regular,500,600,700,800",
                    "Inter:regular,500,600,700",
                ],
            },
        });
    </script>

    <link href="images/fav-icon.svg" rel="shortcut icon" type="image/x-icon" />
</head>

<body class="body" onload="preloader()">
    <div class="loading" id="loading">
        <span>Matrix Operations</span>
    </div>

    <div class="" id="page-wrap" style="display: none">
        <!-- ------------------------------- Nav Bar -------------------------------- -->
        <div class="navbar w-nav">
            <div class="nav-container w-container">
                <a href="index.php" aria-current="page" class="brand w-nav-brand w--current">
                    <img src="images/logo.svg" loading="lazy" alt="" class="image-2" /></a>
                <nav role="navigation" class="nav-menu w-nav-menu">
                    <a href="index.php" aria-current="page" class="nav-link w-nav-link w--current">Home</a>
                    <a href="#about" class="nav-link w-nav-link">About</a>
                    <a href="calculator.php" class="nav-link w-nav-link">Calculator</a>
                    <a href="definitions.html" class="nav-link w-nav-link">Definations</a>
                </nav>
            </div>
        </div>

        <!-- ---------------------------- Hero Section ----------------------------- -->
        <section class="hero-section hero wf-section">
            <div class="container-2 w-container">
                <h1 class="jumbo-heading">
                    Never hustle with <br />
                    <span class="green-span type" style="text-align: initial"><span>Matrix Calculations..!</span></span>
                </h1>
                <p class="paragraph">
                    Matrices are central to the study of linear algebra. They enable
                    mathematicians work with many equations with multiple variable in a
                    systematic way. Matrices are also easily readable by computerized
                    systems.
                </p>
                <a href="calculator.php" class="button btn-glow">Calculate</a>
            </div>
        </section>

        <!-- ---------------------------- About Section ---------------------------- -->
        <section class="about wf-section" id="about">
            <img src="images/Rectangle.svg" loading="lazy" width="57" alt="" class="image-6" />
            <div class="container w-container">
                <div class="small-heading">A breif</div>
                <h1 class="heading-2">About the project</h1>
                <div class="div-block-2">
                    <img src="images/math illustration.png" width="478" alt="math illustration" class="image-3" />
                    <div class="div-block-3">
                        <h4>The Problem</h4>
                        <p class="paragraph-2">
                            Matrix calculations are easier when we are dealing with 3X3 or
                            some small order of the matrix. And the problem comes when we
                            have to perform operations on a 5X5 or 10X10 matrix. Even simple
                            operations like the addition of matrixes would consume lots of
                            time.
                        </p>
                        <h4>The Solution</h4>
                        <p class="paragraph-2">
                            To solve the problem, we decided to develope a website wherein
                            we had implemented all the matrix calculations in an easier way.
                            Whether it is a 3X3 or 10X10 matric calculations of the matrix
                            have been made simpler. With the help of world-class HTML5, CSS3
                            and JS we have developed this site so that performing the
                            operations have been made easier for the user to solve the
                            problem.
                        </p>
                    </div>
                </div>
            </div>
            <img src="images/Ellipse 1.svg" loading="lazy" width="77" alt="" class="image-5" />
        </section>

        <!-- -------------------------- features section --------------------------- -->
        <section class="features-section wf-section">
            <img src="images/matrix.png" loading="lazy" width="115" alt="" class="image-4" />
            <div class="container w-container">
                <div class="small-heading">What we have done</div>
                <h1 class="heading-2">Features included</h1>
                <div class="div-block-2">
                    <div class="w-layout-grid features">
                        <div class="features-card">
                            <div class="feature-heading">The Process</div>
                            <img style="height: 60%; margin: 0 10px 0 0" src="images/process-icon.png" alt="" />
                            <div class="link-block">
                                <a href="process.html" class="link">View more</a>
                                <img src="images/arrow.svg" loading="lazy" width="20" alt="" class="image-7" />
                            </div>
                        </div>

                        <div class="features-card">
                            <div class="feature-heading">Calculator</div>
                            <img style="height: 70%; margin: 0 10px 0 0" src="images/matrix-icon.svg" alt="" />
                            <div class="link-block">
                                <a href="calculator.php" class="link">Matrix Calculator </a>
                                <img src="images/arrow.svg" loading="lazy" width="20" alt="" class="image-7" />
                            </div>
                        </div>

                        <div class="features-card">
                            <div class="feature-heading">Definitions</div>
                            <img style="height: 50%; margin: 0 10px 0 0" src="images/def-icon.svg" alt="" />
                            <div class="link-block">
                                <a href="definitions.html" class="link">Definitions</a>
                                <img src="images/arrow.svg" loading="lazy" width="20" alt="" class="image-7" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ---------------------------- image section ---------------------------- -->
        <div class="image-section wf-section">
            <h1 class="heading-2 white">
                ”  If you think Math is hard, try Web design.”
            </h1>
            <div class="line"></div>
        </div>

        <!-- --------------------------- contact section --------------------------- -->
        <section class="contact wf-section">
            <img src="images/Rectangle.svg" loading="lazy" width="57" alt="" class="image-6" />
            <div class="container w-container">
                <div class="small-heading">what do you think</div>
                <h1 class="heading-2">Feedback/Review</h1>
                <div class="div-block-2">
                    <img src="images/feedback image.png" loading="lazy" style="height: 50%; width: 40%" />
                    <div class="contact-form">
                        <div class="w-form">
                            <!-- ---------------------------- feedback form ---------------------------- -->
                            <form method="post" class="form">
                                <input type="text" class="text-field w-input" style="font-family: 'Poppins';" autocomplete="off" maxlength="256" name="name"  placeholder="Enter your name " id="name" />

                                <input type="email" class="text-field w-input" style="font-family: 'Poppins';" autocomplete="off" maxlength="256" name="email"  placeholder="Enter your email id" id="email" required="" />

                                <textarea class="text-field textarea" style="font-family: inherit;" autocomplete="off" placeholder="Enter your feedback/review here..." maxlength="5000" id="field" rows="6" name="feedback" class="text-field textarea w-input"></textarea>

                                <input type="submit" name="submit" value="Submit"    class="button w-button" />
                            </form>

                            <div class="w-form-done">
                                <div id="done" style="display: none;">
                                    Thank you! Your submission has been received!
                                </div>
                            </div>
                            <div class="w-form-fail">
                                <div id="fail" style="display: none;">
                                    Oops! Something went wrong while submitting the form.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <img src="images/Ellipse 1.svg" loading="lazy" width="77" alt="" class="image-5" />
        </section>

        <!-- --------------------------- footer section ---------------------------- -->
        <footer id="footer" class="footer section-5 wf-section">
            <div class="container-3 w-container">
                <div class="footer-flex-container">
                    <a href="/" aria-current="page" class="footer-logo-link w--current">
                        <img src="images/logo.svg" alt="" class="footer-image div-block-8" /></a>

                    <div class="div-block-8">
                        <h2 class="footer-heading">Important Links</h2>
                        <a href="index.php" aria-current="page" class="footer-link w--current">Home</a>
                        <a href="#about" class="footer-link">About</a>
                        <a href="calculator.php" class="footer-link">Matric Calculator</a>
                        <a href="definitions.html" class="footer-link">Definitions</a>
                    </div>

                    <div class="div-block-8">
                        <h2 class="footer-heading">Team Members</h2>
                        <div class="team">Gagan (140)</div>
                        <div class="team">Nisha (156)</div>
                        <div class="team">Prajwal S U (158)</div>
                        <div class="team">Prajwal S (159)</div>
                    </div>

                    <div class="get-in-touch">
                        <h2 class="footer-heading">Get in touch whit us..!</h2>
                        <div class="w-form">
                            <form id="email-form-2" name="email-form-2" data-name="Email Form 2" method="get">
                                <input type="email" class="text-field white w-input" maxlength="256" name="email-2" data-name="Email 2" placeholder="Enter your email" id="email-2" required="" />
                                <input type="submit" value="Submit" data-wait="Please wait..." class="button button-small w-button" />
                            </form>

                        </div>
                    </div>
                </div>
                <div class="text-block">
                    Copyright © 2022
                    <a style="text-decoration: none;" href="admin_login.php">Project.Matrix</a>
                    All rights reserved.
                </div>
            </div>
        </footer>
    </div>

    <script>
        function preloader() {
            setTimeout(showPage, 2500);
        }

        function showPage() {
            document.getElementById("loading").style.display = "none";
            document.getElementById("page-wrap").style.display = "block";
        }
    </script>
</body>

</html>