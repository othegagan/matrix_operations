<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Project Matrix | Calculator</title>
    <meta content="matrix Calculator" property="og:title" />
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <link rel="stylesheet" href="style.css" />
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js" type="text/javascript"></script>
    <script type="text/javascript">
        WebFont.load({
            google: {
                families: [
                    "Poppins:200,300,regular,500,600,700,800",
                    "Inter:regular,500,600,700",
                ],
            },
        });
    </script>

    <link href="images/fav-icon.svg" rel="shortcut icon" type="image/x-icon" />

    <style>
        * {
            font-family: "Montserrat", sans-serif;
        }

        .arrow-up {
            width: 0;
            height: 0;
            margin-bottom: 7px;
            border-left: 8px solid transparent;
            border-right: 8px solid transparent;
            border-bottom: 15px solid #333;
        }

        .arrow-down {
            width: 0;
            height: 0;
            margin-bottom: 7px;
            border-left: 8px solid transparent;
            border-right: 8px solid transparent;
            border-top: 15px solid #333;
        }

        .arrow-right {
            width: 0;
            height: 0;
            margin-bottom: 7px;
            border-top: 8px solid transparent;
            border-bottom: 8px solid transparent;
            border-left: 15px solid #333;
            display: inline-block;
        }

        .arrow-left {
            width: 0;
            height: 0;
            margin-bottom: 7px;
            margin-right: 10px;
            border-top: 8px solid transparent;
            border-bottom: 8px solid transparent;
            border-right: 15px solid #333;
            display: inline-block;
        }

        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button {
            margin: 0;
        }

        input[type="number"] {
            -moz-appearance: textfield;
        }

        input {
            width: 25px;
            height: 25px;
            border-radius: 3px;
            border: 0;
            border-color: lightgray;
            font-size: 24px;
            padding: 10px 10px;
            margin: 0 10px 10px 0;
            background-color: #e4e4e4;
            font-weight: 300;
            font-size: large;
            text-align: center;
        }

        .panel {
            vertical-align: text-top;
            margin-right: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            flex-wrap: nowrap;
            align-content: stretch;
        }

        .main-form,
        h1 {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }

        #txtbtn {
            font-size: 13px;
            padding: 12px 0px 0px 0px;
        }

        #txtbtn a {
            border-radius: 10px;
            background: #4e4e4e;
            padding: 9px 12px;
            font-size: 15px;
            margin: 13px;
            color: #fff;
            text-decoration: none;
            margin-top: 20px;
        }

        #txtbtn a:hover {
            background: #417516;
            color: #fff;
        }

        .matrixTable {
            border-spacing: 0px;
            border-collapse: separate;
            border-left: 1px solid black;
            border-right: 1px solid black;
        }

        .milti-matrixTable {
            border-spacing: 0px;
            border-collapse: separate;
            border-left: 1px solid black;
            border-right: 1px solid black;
            font-size: 16px;
            font-weight: normal;

        }


        .matrixTable th {
            padding: 0px;
        }

        .matrixTable th:nth-child(1) {
            border-top: 1px solid black;
            border-bottom: 1px solid black;
            width: 3px;
        }

        .matrixTable th:nth-child(3) {
            border-top: 1px solid black;
            border-bottom: 1px solid black;
            width: 3px;
        }

        .matrixTable td {
            padding: 0px 5px;
            text-align: right;
        }

        .err {
            color: #ff0000;
        }
    </style>

    <style>
        @import url("https://fonts.googleapis.com/css?family=Source+Code+Pro:600");


        .matrix {
            /* Center align everything */
            display: flex;
            align-items: center;
            justify-content: center;
            /* position: absolute; */

            /* Perspective */
            perspective: 500px;

            font-size: 0;
            letter-spacing: 0;
            word-spacing: 0;
        }

        .bracket,
        .numbers {
            display: inline-block;
            vertical-align: middle;
        }

        .bracket {
            height: 250px;
            width: 30px;
            border-top: #333 3px solid;
            border-bottom: #333 3px solid;
        }

        .bracket:first-child {
            border-left: #333 3px solid;
        }

        .bracket:last-child {
            border-right: #333 3px solid;
        }

        .numbers {
            /* Rotate the whole matrix */
            transform-style: preserve-3d;
            animation: transposeMatrix 7s 3 linear;
        }

        .n {
            display: inline-block;
            width: 40px;
            height: 40px;
            text-align: center;
            line-height: 100px;
            font-size: 22px;

            /* Rotate the numbers simultaneously with the matrix in reverse direction to keep them facing the screen */
            animation: transposeNumbers 7s 3 linear;
        }


        @keyframes transposeMatrix {
            0% {
                transform: rotate3d(1, 1, 0, 1deg);
            }

            10% {
                transform: rotate3d(1, 1, 0, 1deg);
            }

            30% {
                transform: rotate3d(1, 1, 0, 180deg);
            }

            60% {
                transform: rotate3d(1, 1, 0, 180deg);
            }

            80% {
                transform: rotate3d(1, 1, 0, 360deg);
            }

            100% {
                transform: rotate3d(1, 1, 0, 360deg);
            }
        }

        @keyframes transposeNumbers {
            0% {
                transform: rotate3d(1, 1, 0, 0deg);
            }

            10% {
                transform: rotate3d(1, 1, 0, 0deg);
            }

            30% {
                transform: rotate3d(1, 1, 0, -180deg);
            }

            60% {
                transform: rotate3d(1, 1, 0, -180deg);
            }

            80% {
                transform: rotate3d(1, 1, 0, -360deg);
            }

            100% {
                transform: rotate3d(1, 1, 0, -360deg);
            }
        }
    </style>
</head>

<body onload="preloader(); cClear();">
<div class="loading" id="loading">
        <span>Matrix Operations</span>
    </div>

<div class="" id="page-wrap" style="display: none">
    <!-- ------------------------------- Nav Bar -------------------------------- -->
    <div class="navbar w-nav">
        <div class="nav-container w-container">
            <a href="index.php" aria-current="page" class="brand w-nav-brand w--current">
                <img src="images/logo.svg" loading="lazy" alt="" class="image-2" />
            </a>
            <nav role="navigation" class="nav-menu w-nav-menu">
                <a href="index.php" aria-current="page" class="nav-link w-nav-link">Home</a>
                <a href="index.php#about" class="nav-link w-nav-link">About</a>
                <a href="calculator.php" class="nav-link w-nav-link w--current">Calculator</a>
                <a href="definitions.html" class="nav-link w-nav-link">Definations</a>
            </nav>
        </div>
    </div>

    <!-- ----------------------------- Page title ------------------------------ -->
    <!-- <div class="page-title">
            <h1 class="jumbo-heading"><span class="green-span">Matrix</span> Calculator</h1>
        </div> -->

    <form name="calcf">
        <div class="container-input w-container">
            <div class="box">
                <h2 class="heading-2">Matrix A</h2>
                <div class="panel" style="display: inline-block; vertical-align: text-top">
                    <div class="rows-columns">
                        <p style="margin: 0 40px 0 5px">Rows</p>
                        <p style="margin: 0 40px 0px 45px">Columns</p>
                    </div>
                    <table>
                        <tbody>
                            <tr>
                                <td>
                                    <input type="number" name="arow" value="4" class="in3char" min="1" max="10" onblur="updateInput('a');" />
                                </td>
                                <td>
                                    <div class="arrow-up" onclick="addRemove('a', 'row', 'add');"></div>
                                    <div style="height: 5px"></div>
                                    <div class="arrow-down" onclick="addRemove('a', 'row', 'remove');;"></div>
                                </td>
                                <td></td>
                                <td></td>
                                <td class="verybigtext">
                                    <h3 style="margin: 0 10px 0 0">X</h3>
                                </td>
                                <td>
                                    <input type="number" name="acolumn" value="4" class="in3char" min="1" max="10" onblur="updateInput('a');" />
                                </td>
                                <td>
                                    <div class="arrow-left" onclick="addRemove('a', 'column', 'remove');"></div>
                                    <div class="arrow-right" onclick="addRemove('a', 'column', 'add');"></div>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <div id="minputa"></div>
                </div>

                <br />
                <!-- --------------------------- yellow buttons ---------------------------- -->
                <div class="button-block">
                    <div class="button-layers">
                        <a class="yellow-button w-button" onclick="popValue('a', ''); cClear();">Clear</a>
                        <a class="yellow-button w-button" onclick=" popValue('a', 0);">All 0</a>
                        <a class="yellow-button w-button" onclick=" popValue('a', 1);">All 1</a>
                        <a class="yellow-button w-button" onclick=" popValue('a', 'r');">Random</a>
                    </div>

                    <div class="button-layers">
                        <button id="transpose_count" class="yellow-button w-button" id="trans" onclick=" cTranspose('a')">
                            Transpose
                        </button>
                        <button id="power_count" class="yellow-button w-button" onclick=" cPower('a');">
                            Power of
                        </button>
                        <input type="number" name="pa" value="2" class="in3char" />
                    </div>
                    <div class="button-layers">
                        <button id="determinant_count" class="yellow-button w-button" onclick=" cDeterminant('a');">
                            Determinant
                        </button>
                        <button id="inverse_count" class="yellow-button w-button" onclick=" cInverse('a');">
                            Inverse
                        </button>
                        <button id="multiple_number_count" class="yellow-button w-button button-long" onclick=" cTimes('a');">
                            Multiply A by
                        </button>
                        <input type="number" name="ta" value="3" class="in3char" />
                    </div>
                </div>
            </div>

            <!-- ------------------------------ matrix b ------------------------------- -->
            <div class="box">
                <h2 class="heading-2">Matrix B</h2>
                <div class="panel" style="display: inline-block; vertical-align: text-top">
                    <div class="rows-columns">
                        <p style="margin: 0 40px 0 5px">Rows</p>
                        <p style="margin: 0 40px 0px 45px">Columns</p>
                    </div>
                    <table>
                        <tbody>
                            <tr>
                                <td>
                                    <input type="number" name="brow" value="4" class="in3char" min="1" max="10" onblur="updateInput('b');" />
                                </td>
                                <td>
                                    <div class="arrow-up" onclick="addRemove('b', 'row', 'add');"></div>
                                    <div style="height: 5px"></div>
                                    <div class="arrow-down" onclick="addRemove('b', 'row', 'remove');;"></div>
                                </td>
                                <td class="verybigtext">
                                    <h3 style="margin: 0 10px 0 0">X</h3>
                                </td>

                                <td>
                                    <input type="number" name="bcolumn" value="4" class="in3char" min="1" max="10" onblur="updateInput('b');" />
                                </td>
                                <td>
                                    <div class="arrow-left" onclick="addRemove('b', 'column', 'remove');"></div>
                                    <div class="arrow-right" onclick="addRemove('b', 'column', 'add');"></div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <div id="minputb"></div>
                </div>

                <br />
                <!-- ---------------------------- green-button ----------------------------- -->
                <div class="button-block">
                    <div class="button-layers">
                        <a class="green-button w-button" onclick=" popValue('b', ''); cClear();">Clear</a>
                        <a class="green-button w-button" onclick=" popValue('b', 0);">All 0</a>
                        <a class="green-button w-button" onclick=" popValue('b', 1);">All 1</a>
                        <a class="green-button w-button" onclick=" popValue('b', 'r');">Random</a>
                    </div>

                    <div class="button-layers">
                        <button id="transpose_count_1" class="green-button w-button" onclick=" cTranspose('b'); ">
                            Transpose
                        </button>
                        <button id="power_count_1" class="green-button w-button" onclick=" cPower('b');">
                            Power of
                        </button>
                        <input type="number" name="pb" value="2" class="in3char" />
                    </div>
                    <div class="button-layers">
                        <button id="determinant_count_1" class="green-button w-button" onclick=" cDeterminant('b');">
                            Determinant
                        </button>
                        <button id="inverse_count_1" class="green-button w-button" onclick=" cInverse('b');">
                            Inverse
                        </button>
                        <button id="multiple_number_count_1" class="green-button w-button button-long" onclick=" cTimes('b');">
                            Multiply B by
                        </button>
                        <input type="number" name="tb" value="3" class="in3char" />
                    </div>
                </div>
            </div>
        </div>
    </form>

    <!-- ---------------------------- Blue buttons ----------------------------- -->
    <div class="blue-container">
        <button id="add_count" class="blue-button w-button" onclick=" cAdd();">
            A + B
        </button>
        <button id="sub_count" class="blue-button w-button" onclick=" cSub();">
            A - B
        </button>
        <button id="mult_count" class="blue-button w-button" onclick=" cMultiple();">
            A B
        </button>
        <button id="swap_count" class="blue-button w-button" onclick=" cSwap();">
            A ↔ B
        </button>
    </div>

    <!-- --------------------------- output section ---------------------------- -->
    <div class="output-section wf-section" id="output-section">
        <h1 class="output-heading">OUTPUT</h1>

        <div class="div-block-9">
            <!-- for matrix A and matrix B -->
            <div id="fullMult" style="display: flex; display: none; margin: 30px 0;">
                A =
                <div id="matA"></div>
                B = &nbsp;&nbsp;
                <div id="matB"></div>
            </div>
            <!-- for detailed steps -->
            <div id="output-steps">
                <div id="steps-title"></div>
                <div class="matrixTable" id="steps"></div>
            </div>

            <div id="multiplication"></div>
            <div id="multi-additonSteps"></div>

            <div id="transpose-animation" style="    display: flex; align-content: center;">
                <div style="margin: 0 20px; display: flex;">
                    <div class="steps-title" id="transpose-original-title"></div>
                    <div class="steps" id="original"></div>
                </div>

                <div style="margin: 0 20px; display: flex;">
                    <div class="steps-title" id="transpose-result-title"></div>
                    <div class="steps" id="transpose-result"></div>
                </div>
            </div>

            <!-- for single operation result -->
            <div id="resultout"></div>
            <div id="resultouta"></div>
            <div id="resultoutb"></div>

            <div class="matrix" id="matrix">
                <div class="numbers" id="numbers"></div>
            </div>
        </div>

        <div class="bottom-text">
            Find all the operation’s definations with example here..!
            <a href="definitions.html"><span class="green-span-link">Definations</span></a>
        </div>

        <img src="images/design 2.svg" loading="lazy" width="169" alt="" class="image-11" />
        <img src="images/Rectangle.svg" loading="lazy" width="58" alt="" class="image-12" />
    </div>

    <!-- --------------------------- footer section ---------------------------- -->
    <footer id="footer" class="footer section-5 wf-section">
        <div class="container-3 w-container">
            <div class="footer-flex-container">
                <a href="/" aria-current="page" class="footer-logo-link w--current">
                    <img src="images/logo.svg" alt="" class="footer-image div-block-8" />
                </a>
                <div class="div-block-8">
                    <h2 class="footer-heading">Important Links</h2>
                    <a href="index.php" aria-current="page" class="footer-link w--current">Home</a>
                    <a href="#about" class="footer-link">About</a>
                    <a href="calculator.php" class="footer-link">Matric Calculator</a>
                    <a href="definitions.html" class="footer-link">Definitions</a>
                </div>
                <div class="div-block-8">
                    <h2 class="footer-heading">Team Members</h2>
                    <div class="team">Gagan (140)</div>
                    <div class="team">Nisha (156)</div>
                    <div class="team">Prajwal S U (158)</div>
                    <div class="team">Prajwal S (159)</div>
                </div>
                <div class="get-in-touch">
                    <h2 class="footer-heading">Get in touch whit us..!</h2>
                    <div class="w-form">
                        <form id="email-form-2" name="email-form-2" data-name="Email Form 2" method="get">
                            <input type="email" class="text-field white w-input" maxlength="256" name="email-2" data-name="Email 2" placeholder="Enter your email" id="email-2" required="" />
                            <input type="submit" value="Submit" data-wait="Please wait..." class="button button-small w-button" />
                        </form>
                    </div>
                </div>
            </div>
            <div class="text-block">
                Copyright © 2022 Project.Matrix All rights reserved.
            </div>
        </div>
    </footer>
</div>

    <script name="calculation">
        var matrixa = new Array(10);
        var matrixb = new Array(10);
        for (var i = 0; i < 10; i++) {
            matrixa[i] = new Array(10);
            matrixb[i] = new Array(10);
            for (var j = 0; j < 10; j++) {
                matrixa[i][j] = "";
                matrixb[i][j] = "";
            }
        }

        function setfocus() {
            document.getElementById('output-section').focus();
        }

        function addRemove(arname, arfield, arop) {
            var arFieldName = arname;
            if (arfield == "row") {
                arFieldName += "row";
            } else {
                arFieldName += "column";
            }
            eval("var thisField = document.calcf." + arFieldName);
            var thisValue = thisField.value;
            if (arop == "add") thisValue++;
            if (arop == "remove") thisValue--;
            if (thisValue < 1) thisValue = 1;
            if (thisValue > 10) thisValue = 10;
            thisField.value = thisValue;
            readInput(arname);
            updateInput(arname);
            return false;
        }

        function readInput(mname) {
            for (var i = 0; i < 10; i++) {
                for (var j = 0; j < 10; j++) {
                    eval("var thisField = document.calcf." + mname + i + j);
                    if (!(thisField === undefined)) {
                        if (mname == "a") matrixa[i][j] = thisField.value;
                        if (mname == "b") matrixb[i][j] = thisField.value;
                    }
                }
            }
        }

        function updateInput(mname) {
            eval("var rowField = document.calcf." + mname + "row");
            eval("var columnField = document.calcf." + mname + "column");
            var rowAmt = rowField.value;
            var columnAmt = columnField.value;
            if (rowAmt < 1) {
                rowAmt = 1;
                rowField.value = rowAmt;
            }
            if (rowAmt > 10) {
                rowAmt = 10;
                rowField.value = rowAmt;
            }
            if (columnAmt < 1) {
                columnAmt = 1;
                columnField.value = columnAmt;
            }
            if (columnAmt > 10) {
                columnAmt = 10;
                columnField.value = columnAmt;
            }
            var outHMTL = "<table>";
            for (var i = 0; i < rowAmt; i++) {
                outHMTL += "<tr>";
                for (var j = 0; j < columnAmt; j++) {
                    if (mname == "a")
                        outHMTL +=
                        '<td><input type="text" name="a' +
                        i +
                        j +
                        '" value="' +
                        matrixa[i][j] +
                        '" class="in4char"></td>';
                    if (mname == "b")
                        outHMTL +=
                        '<td><input type="text" name="b' +
                        i +
                        j +
                        '" value="' +
                        matrixb[i][j] +
                        '" class="in4char"></td>';
                }
                outHMTL += "</tr>";
            }
            outHMTL += "</table>";
            document.getElementById("minput" + mname).innerHTML = outHMTL;
        }

        function popValue(mname, mtype) {
            for (var i = 0; i < 10; i++) {
                for (var j = 0; j < 10; j++) {
                    var thisVal = mtype;
                    if (mtype == "r") thisVal = Math.floor(Math.random() * 10);
                    eval("var thisField = document.calcf." + mname + i + j);
                    if (mname == "a") matrixa[i][j] = thisVal;
                    if (mname == "b") matrixb[i][j] = thisVal;
                    if (!(thisField === undefined)) thisField.value = thisVal;
                }
            }
            return false;
        }

        updateInput("a");
        updateInput("b");
        var aArray = new Array();
        var bArray = new Array();
        var resultArray = new Array();
        var multiplyArray = new Array();
        var aValid = true;
        var bValid = true;
        var aRowAmt = 0;
        var bRowAmt = 0;
        var aColumnAmt = 0;
        var bColumnAmt = 0;
        var hasError = false;
        var errMsg = "";
        let power_counter = 0;
        let times_counter = 0;
        let determinant_counter = 0;

        function cClear() {
            document.getElementById("resultout").innerHTML = "";
            document.getElementById("resultouta").innerHTML = "";
            document.getElementById("resultoutb").innerHTML = "";
            document.getElementById("numbers").innerHTML = "";
            document.getElementById("steps").innerHTML = "";
            document.getElementById("steps-title").innerHTML = "";
            document.getElementById("original").innerHTML = "";
            document.getElementById("transpose-result").innerHTML = "";
            document.getElementById("transpose-original-title").innerHTML = "";
            document.getElementById("transpose-result-title").innerHTML = "";
            document.getElementById('fullMult').style.display = "none";

            if ((document.getElementById('multiplication').innerHTML) != "")
                document.getElementById('multiplication').innerHTML = ""

            if ((document.getElementById('multi-additonSteps').innerHTML) != "")
                document.getElementById('multi-additonSteps').innerHTML = ""

            aValid = true;
            bValid = true;
            hasError = false;
            errMsg = "";
            aArray = new Array();
            bArray = new Array();
            resultArray = new Array();

            var tempRow = document.calcf.arow.value + "";
            var tempColumn = document.calcf.acolumn.value + "";
            if (
                tempRow.length > 0 &&
                tempColumn.length > 0 &&
                isInteger(tempRow) &&
                isInteger(tempColumn)
            ) {
                tempRow = parseInt(tempRow);
                tempColumn = parseInt(tempColumn);
                if (
                    tempRow > 0 &&
                    tempRow < 11 &&
                    tempColumn > 0 &&
                    tempColumn < 11
                ) {
                    for (var i = 0; i < tempRow; i++) {
                        aArray[i] = new Array();
                        for (var j = 0; j < tempColumn; j++) {
                            eval(
                                "var tempVal = document.calcf.a" +
                                i +
                                j +
                                ".value"
                            );
                            var tempValStr = "" + tempVal;
                            if (tempValStr.length > 0) {
                                if (!isNumber(tempValStr)) {
                                    aValid = false;
                                } else {
                                    tempVal = parseFloat(tempVal);
                                }
                            } else {
                                tempVal = 0;
                            }
                            aArray[i][j] = tempVal;
                        }
                    }
                    aRowAmt = tempRow;
                    aColumnAmt = tempColumn;
                } else {
                    aValid = false;
                }
            } else {
                aValid = false;
            }
            var tempRow = document.calcf.brow.value + "";
            var tempColumn = document.calcf.bcolumn.value + "";
            if (
                tempRow.length > 0 &&
                tempColumn.length > 0 &&
                isInteger(tempRow) &&
                isInteger(tempColumn)
            ) {
                tempRow = parseInt(tempRow);
                tempColumn = parseInt(tempColumn);
                if (
                    tempRow > 0 &&
                    tempRow < 11 &&
                    tempColumn > 0 &&
                    tempColumn < 11
                ) {
                    for (var i = 0; i < tempRow; i++) {
                        bArray[i] = new Array();
                        for (var j = 0; j < tempColumn; j++) {
                            eval(
                                "var tempVal = document.calcf.b" +
                                i +
                                j +
                                ".value"
                            );
                            var tempValStr = "" + tempVal;
                            if (tempValStr.length > 0) {
                                if (!isNumber(tempValStr)) {
                                    bValid = false;
                                } else {
                                    tempVal = parseFloat(tempVal);
                                }
                            } else {
                                tempVal = 0;
                            }
                            bArray[i][j] = tempVal;
                        }
                    }
                    bRowAmt = tempRow;
                    bColumnAmt = tempColumn;
                } else {
                    bValid = false;
                }
            } else {
                bValid = false;
            }
        }

        function cPower(mname) {
            cClear();
            var ctNum = 1;
            var tempArray = new Array();
            var ctDesc = "";
            if (mname == "a") {
                ctNum = document.calcf.pa.value + "";
                if (!aValid) {
                    hasError = true;
                    errMsg =
                        '<div class="err">Please provide valid data in Matrix A.</div>';
                }
                if (aRowAmt != aColumnAmt) {
                    hasError = true;
                    errMsg +=
                        '<div class="err">The row and column size need to be the same.</div>';
                }
                tempArray = aArray;
                ctDesc = "A<sup>" + ctNum + "</sup> =";
            } else {
                ctNum = document.calcf.pb.value + "";
                if (!bValid) {
                    hasError = true;
                    errMsg =
                        '<div class="err">Please provide valid data in Matrix B.</div>';
                }
                if (bRowAmt != bColumnAmt) {
                    hasError = true;
                    errMsg +=
                        '<div class="err">The row and column size need to be the same.</div>';
                }
                tempArray = bArray;
                ctDesc = "B<sup>" + ctNum + "</sup> =";
            }
            if (ctNum.length < 1 || !isInteger(ctNum)) {
                errMsg +=
                    '<div class="err">Please provide a positive integer power value.</div>';
                hasError = true;
            } else {
                ctNum = parseInt(ctNum);
                if (ctNum < 1) {
                    errMsg +=
                        '<div class="err">Please provide a positive integer power value.</div>';
                    hasError = true;
                }
            }

            if (hasError) {
                showErr("resultout" + mname, errMsg);
            } else {
                resultArray = tempArray;
                var tempSize = tempArray.length;
                for (var m = 0; m < ctNum - 1; m++) {
                    var newResultA = new Array();
                    for (var i = 0; i < tempSize; i++) {
                        newResultA[i] = new Array();
                        for (var j = 0; j < tempSize; j++) {
                            newResultA[i][j] = 0;
                            for (var k = 0; k < tempSize; k++) {
                                newResultA[i][j] += resultArray[i][k] * tempArray[k][j];
                            }
                        }
                    }
                    resultArray = newResultA;
                }
                showResult("resultout" + mname, ctDesc, showArray(resultArray));
                power_counter++;
            }
            return false;
        }

        function cTimes(mname) {
            cClear();
            var ctNum = 1;
            var tempArray = new Array();
            var ctDesc = "";
            if (mname == "a") {
                ctNum = document.calcf.ta.value + "";
                if (!aValid) {
                    hasError = true;
                    errMsg =
                        '<div class="err">Please provide valid data in Matrix A.</div>';
                }
                tempArray = aArray;
                ctDesc = "A &#215 " + ctNum + " =";
            } else {
                ctNum = document.calcf.tb.value + "";
                if (!bValid) {
                    hasError = true;
                    errMsg =
                        '<div class="err">Please provide valid data in Matrix B.</div>';
                }
                tempArray = bArray;
                ctDesc = "B &#215 " + ctNum + " =";
            }

            if (ctNum.length < 1 || !isNumber(ctNum)) {
                errMsg +=
                    '<div class="err">Please provide a value to multiple.</div>';
                hasError = true;
            }

            if (hasError) {
                showErr("resultout" + mname, errMsg);
            } else {
                ctNum = parseFloat(ctNum);
                // for display of steps
                document.getElementById('steps-title').innerHTML = ctDesc
                for (var i = 0; i < tempArray.length; i++) {
                    resultArray[i] = new Array();
                    for (var j = 0; j < tempArray[i].length; j++) {
                        document.getElementById('steps').innerHTML += tempArray[i][j] + "X" + ctNum + "\t\t\t\t"
                    }
                    document.getElementById('steps').innerHTML += "</br>"
                }

                // for actal calculatin
                for (var i = 0; i < tempArray.length; i++) {
                    resultArray[i] = new Array();
                    for (var j = 0; j < tempArray[i].length; j++) {
                        resultArray[i][j] = tempArray[i][j] * ctNum;
                    }
                }
                times_counter++;
                showResult("resultout" + mname, ctDesc, showArray(resultArray));
            }
            return false;
        }

        function findDet(fdArray, fdSize) {
            if (fdSize < 3) {
                if (fdSize < 2) {
                    return fdArray[0][0];
                } else {
                    return (
                        fdArray[0][0] * fdArray[1][1] -
                        fdArray[0][1] * fdArray[1][0]
                    );
                }
            } else {
                var signVal = -1;
                var tempOutVal = 0;
                for (var i = 0; i < fdSize; i++) {
                    signVal *= -1;
                    var tempArray = new Array();
                    var c = 0;
                    for (var j = 0; j < fdSize; j++) {
                        if (i != j) {
                            tempArray[c] = new Array();
                            for (var k = 1; k < fdSize; k++) {
                                tempArray[c][k - 1] = fdArray[j][k];
                            }
                            c++;
                        }
                    }
                    tempOutVal += signVal * fdArray[i][0] * findDet(tempArray, fdSize - 1);
                }
                return tempOutVal;
            }
        }

        function cDeterminant(mname) {
            cClear();
            var cdSize = 1;
            var tempArray = new Array();
            var ctDesc = "";

            if (mname == "a") {
                if (!aValid) {
                    hasError = true;
                    errMsg =
                        '<div class="err">Please provide valid data in Matrix A.</div>';
                }
                if (aRowAmt != aColumnAmt) {
                    hasError = true;
                    errMsg +=
                        '<div class="err">The row and column size need to be the same.</div>';
                }
                cdSize = aRowAmt;
                tempArray = aArray;
                ctDesc = "Determinant of A =";
            } else {
                if (!bValid) {
                    hasError = true;
                    errMsg =
                        '<div class="err">Please provide valid data in Matrix B.</div>';
                }
                if (bRowAmt != bColumnAmt) {
                    hasError = true;
                    errMsg +=
                        '<div class="err">The row and column size need to be the same.</div>';
                }
                cdSize = bRowAmt;
                tempArray = bArray;
                ctDesc = "Determinant of B =";
            }

            if (hasError) {
                showErr("resultout" + mname, errMsg);
            } else {
                document.getElementById("resultout" + mname).innerHTML =
                    '<h2 class="h2result">Result</h2><p class="verybigtext">' +
                    ctDesc + " " + findDet(tempArray, cdSize) + "</p>";
                //showResult("resultout"+mname, ctDesc, findDet(tempArray, cdSize));
            }
            return false;
        }

        function cInverse(mname) {
            cClear();
            var cdSize = 1;
            var tempArray = new Array();
            var ctDesc = "";
            if (mname == "a") {
                if (!aValid) {
                    hasError = true;
                    errMsg =
                        '<div class="err">Please provide valid data in Matrix A.</div>';
                }
                if (aRowAmt != aColumnAmt) {
                    hasError = true;
                    errMsg +=
                        '<div class="err">The row and column size need to be the same.</div>';
                }
                cdSize = aRowAmt;
                tempArray = aArray;
                ctDesc = "A<sup>-1</sup> =";
            } else {
                if (!bValid) {
                    hasError = true;
                    errMsg =
                        '<div class="err">Please provide valid data in Matrix B.</div>';
                }
                if (bRowAmt != bColumnAmt) {
                    hasError = true;
                    errMsg +=
                        '<div class="err">The row and column size need to be the same.</div>';
                }
                cdSize = bRowAmt;
                tempArray = bArray;
                ctDesc = "B<sup>-1</sup> =";
            }

            if (hasError) {
                showErr("resultout" + mname, errMsg);
            } else {
                var tempDetVal = findDet(tempArray, cdSize);


                if (tempDetVal == 0) {
                    showErr(
                        "resultout" + mname,
                        '<div class="err">Determinant is 0. Inverse does not exist.</div>'
                    );
                } else {
                    //create Cofactor Matrix cdSize
                    if (cdSize < 2) {
                        resultArray[0] = new Array();
                        resultArray[0][0] = 1 / tempArray[0][0];
                    } else {
                        for (var i = 0; i < cdSize; i++) {
                            resultArray[i] = new Array();
                            for (var j = 0; j < cdSize; j++) {
                                var signVal = Math.pow(-1, i + j);

                                var x = 0;
                                var y = 0;
                                var tempArray2 = new Array();
                                for (var m = 0; m < cdSize; m++) {
                                    if (m != i) {
                                        tempArray2[x] = new Array();
                                        y = 0;
                                        for (var n = 0; n < cdSize; n++) {
                                            if (n != j) {
                                                tempArray2[x][y] = tempArray[m][n];
                                                y++;
                                            }
                                        }
                                        x++;
                                    }
                                }
                                resultArray[i][j] = signVal * findDet(tempArray2, cdSize - 1);
                            }
                        }

                        for (var i = 0; i < cdSize; i++) {
                            for (var j = 0; j < cdSize; j++) {
                                tempArray[j][i] = resultArray[i][j] / tempDetVal.toPrecision(2);
                            }
                        }
                        resultArray = tempArray;
                    }
                    showResult(
                        "resultout" + mname, ctDesc, showArray(resultArray)
                    );
                }
            }
            return false;
        }

        function cTranspose(mname) {
            cClear();
            var ctNum = 1;
            var tempArray = new Array();
            var ctDesc = "";
            if (mname == "a") {
                if (!aValid) {
                    hasError = true;
                    errMsg =
                        '<div class="err">Please provide valid data in Matrix A.</div>';
                }
                tempArray = aArray;
                ctDesc = "A<sup>T</sup> =";
                var matrixName = 'A'
            } else {
                if (!bValid) {
                    hasError = true;
                    errMsg =
                        '<div class="err">Please provide valid data in Matrix B.</div>';
                }
                tempArray = bArray;
                var matrixName = 'B'
                ctDesc = "B<sup>T</sup> =";
            }
            if (hasError) {
                showErr("resultout" + mname, errMsg);
            } else {

                // for printing steps
                document.getElementById('transpose-original-title').innerHTML += matrixName + "  =" + '<div class="brackets"></div>';
                for (let i = 0; i < tempArray.length; i++) {
                    let innerArrayLength = tempArray[i].length;
                    for (let j = 0; j < innerArrayLength; j++) {
                        document.getElementById('original').innerHTML += tempArray[i][j] + "\t\t\t\t"
                    }
                    document.getElementById('original').innerHTML += "<br>";
                }

                // for acutal display of the result
                document.getElementById('transpose-result-title').innerHTML += ctDesc;
                for (var i = 0; i < tempArray[0].length; i++) {
                    resultArray[i] = new Array();
                    for (var j = 0; j < tempArray.length; j++) {
                        resultArray[i][j] = tempArray[j][i];
                        document.getElementById('transpose-result').innerHTML += resultArray[i][j] + "\t\t\t\t"
                    }
                    document.getElementById('transpose-result').innerHTML += "<br>";
                }



                implementationOf2Darray(resultArray);
                // showResult(
                //     "resultout" + mname,
                //     ctDesc,
                //     showArray(resultArray)
                // );
            }
            return false;
        }

        function implementationOf2Darray(arr) {
            if (arr.length >= 4) {
                document.getElementById("numbers").style.width = "190px";
            }
            if (arr.length >= 5) {
                document.getElementById("numbers").style.width = "210px";
            }
            for (let i = 0; i < arr.length; i++) {
                let innerArrayLength = arr[i].length;

                for (let j = 0; j < innerArrayLength; j++) {
                    document.getElementById("numbers").innerHTML += '<div class="n">' + arr[i][j] + "</div>";
                }
            }
        }



        function cAdd() {
            cClear();
            if (!aValid) {
                hasError = true;
                errMsg =
                    '<div class="err">Please provide valid data in Matrix A.</div>';
            }
            if (!bValid) {
                hasError = true;
                errMsg +=
                    '<div class="err">Please provide valid data in Matrix B.</div>';
            }
            if (hasError) {
                showErr("resultout", errMsg);
            } else {
                if (aRowAmt == bRowAmt && aColumnAmt == bColumnAmt) {

                    // for printing steps
                    document.getElementById('steps-title').innerHTML = "A + B ="
                    for (var i = 0; i < aRowAmt; i++) {
                        resultArray[i] = new Array();
                        for (var j = 0; j < aColumnAmt; j++) {
                            document.getElementById('steps').innerHTML += aArray[i][j] + "+" + bArray[i][j] + "\t\t";
                        }
                        document.getElementById('steps').innerHTML += "<br>"
                    }

                    // for actual calculation
                    for (var i = 0; i < aRowAmt; i++) {
                        resultArray[i] = new Array();
                        for (var j = 0; j < aColumnAmt; j++) {
                            resultArray[i][j] = aArray[i][j] + bArray[i][j];
                        }
                    }
                    document.getElementById('fullMult').style.display = "flex";
                    stringOutput("matA", aArray);
                    stringOutput("matB", bArray);
                    showResult("resultout", "A + B =", showArray(resultArray));
                } else {
                    showErr(
                        "resultout",
                        '<div class="err">Matrix A and B need to be the same in size.</div>'
                    );
                }
            }
            return false;
        }

        function cSub() {
            cClear();
            if (!aValid) {
                hasError = true;
                errMsg =
                    '<div class="err">Please provide valid data in Matrix A.</div>';
            }
            if (!bValid) {
                hasError = true;
                errMsg +=
                    '<div class="err">Please provide valid data in Matrix B.</div>';
            }
            if (hasError) {
                showErr("resultout", errMsg);
            } else {
                if (aRowAmt == bRowAmt && aColumnAmt == bColumnAmt) {
                    // for printing steps
                    document.getElementById('steps-title').innerHTML = "A - B ="
                    for (var i = 0; i < aRowAmt; i++) {
                        resultArray[i] = new Array();
                        for (var j = 0; j < aColumnAmt; j++) {
                            document.getElementById('steps').innerHTML += aArray[i][j] + "-" + bArray[i][j] + "\t\t";
                        }
                        document.getElementById('steps').innerHTML += "<br>"
                    }

                    // for actual calculation
                    for (var i = 0; i < aRowAmt; i++) {
                        resultArray[i] = new Array();
                        for (var j = 0; j < aColumnAmt; j++) {
                            resultArray[i][j] = aArray[i][j] - bArray[i][j];
                        }
                    }
                    showResult(
                        "resultout",
                        "A &ndash; B =",
                        showArray(resultArray)
                    );
                } else {
                    showErr(
                        "resultout",
                        '<div class="err">Matrix A and B need to be the same in size.</div>'
                    );
                }
            }
            return false;
        }

        function cMultiple() {
            cClear();
            if (!aValid) {
                hasError = true;
                errMsg =
                    '<div class="err">Please provide valid data in Matrix A.</div>';
            }
            if (!bValid) {
                hasError = true;
                errMsg +=
                    '<div class="err">Please provide valid data in Matrix B.</div>';
            }
            if (hasError) {
                showErr("resultout", errMsg);
            } else {
                if (aColumnAmt == bRowAmt) {

                    var additionArray = new Array();
                    // for printing the steps
                    for (var i = 0; i < aRowAmt; i++) {
                        multiplyArray[i] = new Array();
                        additionArray[i] = new Array();
                        for (var j = 0; j < bColumnAmt; j++) {
                            multiplyArray[i][j] = "";
                            additionArray[i][j] = ""
                            for (var k = 0; k < aColumnAmt; k++) {
                                if ((k + 1) < aColumnAmt) {
                                    multiplyArray[i][j] += "(" + aArray[i][k] + " X " + bArray[k][j] + ") +";
                                    additionArray[i][j] += aArray[i][k] * bArray[k][j] + " +";
                                } else {
                                    multiplyArray[i][j] += "(" + aArray[i][k] + " X " + bArray[k][j] + ")";
                                    additionArray[i][j] += aArray[i][k] + bArray[k][j];
                                }
                            }
                        }
                    }

                    document.getElementById('fullMult').style.display = "flex";
                    stringOutput("matA", aArray);
                    stringOutput("matB", bArray);

                    stringOutput("multiplication", multiplyArray);
                    stringOutput("multi-additonSteps", additionArray);



                    // for actual calculation
                    for (var i = 0; i < aRowAmt; i++) {
                        resultArray[i] = new Array();
                        for (var j = 0; j < bColumnAmt; j++) {
                            resultArray[i][j] = 0;
                            for (var k = 0; k < aColumnAmt; k++) {
                                resultArray[i][j] += aArray[i][k] * bArray[k][j];
                            }
                        }
                    }
                    showResult("resultout", "AB =", showArray(resultArray));
                } else {
                    showErr(
                        "resultout",
                        '<div class="err">Matrix A column and B row amount need to be the same.</div>'
                    );
                }
            }
            return false;
        }

        function stringOutput(sid, iparray) {
            var resultString = '<table  class="milti-matrixTable" >';
            for (var i = 0; i < iparray.length; i++) {
                resultString += '<tr style=" padding: 5px 10px;">';
                for (var j = 0; j < iparray[i].length; j++)
                    resultString += '<td style=" padding: 6px 10px;">' + iparray[i][j] + "</td>";
                resultString += '<tr style=" padding: 5px 10px;">';
            }
            resultString += "</table>";

            document.getElementById(sid).innerHTML = resultString;
        }


        function cSwap() {
            cClear();
            readInput("a");
            readInput("b");
            var tempRow = document.calcf.arow.value;
            var tempColumn = document.calcf.acolumn.value;
            document.calcf.arow.value = document.calcf.brow.value;
            document.calcf.acolumn.value = document.calcf.bcolumn.value;
            document.calcf.brow.value = tempRow;
            document.calcf.bcolumn.value = tempColumn;
            var tempArray = matrixa;
            matrixa = matrixb;
            matrixb = tempArray;
            updateInput("a");
            updateInput("b");
            document.getElementById("resultout").innerHTML =
                "<div>Matrix A and B were swapped.</div>";
            return false;
        }

        function cpToA() {
            var ctRow = resultArray.length;
            var ctColumn = resultArray[0].length;
            document.calcf.arow.value = ctRow;
            document.calcf.acolumn.value = ctColumn;
            for (var i = 0; i < 10; i++) {
                for (var j = 0; j < 10; j++) {
                    matrixa[i][j] = "";
                }
            }
            for (var i = 0; i < ctRow; i++) {
                for (var j = 0; j < ctColumn; j++) {
                    matrixa[i][j] = resultArray[i][j];
                }
            }
            updateInput("a");
            return false;
        }

        function cpToB() {
            var ctRow = resultArray.length;
            var ctColumn = resultArray[0].length;
            document.calcf.brow.value = ctRow;
            document.calcf.bcolumn.value = ctColumn;
            for (var i = 0; i < 10; i++) {
                for (var j = 0; j < 10; j++) {
                    matrixb[i][j] = "";
                }
            }
            for (var i = 0; i < ctRow; i++) {
                for (var j = 0; j < ctColumn; j++) {
                    matrixb[i][j] = resultArray[i][j];
                }
            }
            updateInput("b");
            return false;
        }

        function isNumber(val) {
            val = val + "";
            if (val.length < 1) return false;
            if (isNaN(val)) {
                return false;
            } else {
                return true;
            }
        }

        function isInteger(val) {
            if (isNumber(val)) {
                return val % 1 === 0;
            } else {
                return false;
            }
        }


        function formatNum(inNum) {
            outStr = "" + inNum;
            inNum = parseFloat(outStr);
            if (outStr.length > 10) {
                outStr = "" + inNum.toPrecision(10);
            }
            if (outStr.indexOf(".") > -1) {
                while (outStr.charAt(outStr.length - 1) == "0") {
                    outStr = outStr.substr(0, outStr.length - 1);
                }
                if (outStr.charAt(outStr.length - 1) == ".")
                    outStr = outStr.substr(0, outStr.length - 1);
                return outStr;
            } else {
                return outStr;
            }
        }

        function showArray(saArray) {
            var saOut = '<table class="matrixTable"><tr><th></th><th><table>';
            for (var i = 0; i < saArray.length; i++) {
                saOut += "<tr>";
                for (var j = 0; j < saArray[i].length; j++)
                    saOut += "<td>" + formatNum(saArray[i][j]) + "</td>";
                saOut += "</tr>";
            }
            saOut += "</table></th><th></th></tr></table>";
            return saOut;
        }

        function showErr(seID, seMsg) {
            document.getElementById(seID).innerHTML = seMsg;
        }

        function showResult(srID, srNote, srVar) {
            document.getElementById(srID).innerHTML =
                '<table><tr><td valign="top" nowrap><span class="verybigtext">' +
                srNote +
                '<br><br></span><br><br><a  onClick="return  cpToA();"> <br><br > Copy result To A</a><br>' +
                '<a href="#" onClick="return cpToB();"> <br> Copy result To B</a></td><td valign="top">' +
                srVar +
                "</td></tr></table>";
        }
    </script>

    <script language="JavaScript" type="text/javascript">
        $(document).ready(function() {

            $("#add_count").click(function() {
                var add = 1;
                var dataString = 'add_count=' + add;
                // AJAX Code To Submit Form.
                $.ajax({
                    type: "POST",
                    url: "senddata.php",
                    data: dataString,
                    cache: false,
                    success: function(result) {
                        alert("inserted...!")
                        add = 0;
                    }
                });
                return false;
            });

            $("#sub_count").click(function() {
                var sub = 1;
                var dataString = 'sub_count=' + sub;
                // AJAX Code To Submit Form.
                $.ajax({
                    type: "POST",
                    url: "senddata.php",
                    data: dataString,
                    cache: false,
                    success: function(result) {
                        sub = 0;
                    }
                });
                return false;
            });

            $("#mult_count").click(function() {
                var mult = 1;
                var dataString = 'mult_count=' + mult;
                $.ajax({
                    type: "POST",
                    url: "senddata.php",
                    data: dataString,
                    cache: false,
                    success: function(result) {
                        mult = 0;
                    }
                });
                return false;
            });

            $("#swap_count").click(function() {
                var swap = 1;
                var dataString = 'swap_count=' + swap;
                $.ajax({
                    type: "POST",
                    url: "senddata.php",
                    data: dataString,
                    cache: false,
                    success: function(result) {
                        swap = 0;
                    }
                });
                return false;
            });

            // for martix A
            $("#transpose_count").click(function() {
                var transpose = 1;
                var dataString = 'transpose_count=' + transpose;
                $.ajax({
                    type: "POST",
                    url: "senddata.php",
                    data: dataString,
                    cache: false,
                    success: function(result) {
                        transpose = 0;
                    }
                });
                return false;
            });

            $("#power_count").click(function() {
                var power = 1;
                var dataString = 'power_count=' + power;
                $.ajax({
                    type: "POST",
                    url: "senddata.php",
                    data: dataString,
                    cache: false,
                    success: function(result) {
                        power = 0;
                    }
                });
                return false;
            });

            $("#determinant_count").click(function() {
                var determinant = 1;
                var dataString = 'determinant_count=' + determinant;
                $.ajax({
                    type: "POST",
                    url: "senddata.php",
                    data: dataString,
                    cache: false,
                    success: function(result) {
                        determinant = 0;
                    }
                });
                return false;
            });

            $("#inverse_count").click(function() {
                var inverse = 1;
                var dataString = 'inverse_count=' + inverse_count;
                $.ajax({
                    type: "POST",
                    url: "senddata.php",
                    data: dataString,
                    cache: false,
                    success: function(result) {
                        inverse_count = 0;
                    }
                });
                return false;
            });

            $("#multiple_number_count").click(function() {
                var multiply_number = 1;
                var dataString = 'multiple_number_count=' + multiply_number;
                $.ajax({
                    type: "POST",
                    url: "senddata.php",
                    data: dataString,
                    cache: false,
                    success: function(result) {
                        inverse_count = 0;
                    }
                });
                return false;
            });


            // for matrix b
            $("#transpose_count_1").click(function() {
                var transpose = 1;
                var dataString = 'transpose_count=' + transpose;
                $.ajax({
                    type: "POST",
                    url: "senddata.php",
                    data: dataString,
                    cache: false,
                    success: function(result) {
                        transpose = 0;
                    }
                });
                return false;
            });

            $("#power_count_1").click(function() {
                var power = 1;
                var dataString = 'power_count=' + power;
                $.ajax({
                    type: "POST",
                    url: "senddata.php",
                    data: dataString,
                    cache: false,
                    success: function(result) {
                        power = 0;
                    }
                });
                return false;
            });

            $("#determinant_count_1").click(function() {
                var determinant = 1;
                var dataString = 'determinant_count=' + determinant;
                $.ajax({
                    type: "POST",
                    url: "senddata.php",
                    data: dataString,
                    cache: false,
                    success: function(result) {
                        determinant = 0;
                    }
                });
                return false;
            });

            $("#inverse_count_1").click(function() {
                var inverse = 1;
                var dataString = 'inverse_count=' + inverse_count;
                $.ajax({
                    type: "POST",
                    url: "senddata.php",
                    data: dataString,
                    cache: false,
                    success: function(result) {
                        inverse_count = 0;
                    }
                });
                return false;
            });

            $("#multiple_number_count_1").click(function() {
                var multiply_number = 1;
                var dataString = 'multiple_number_count=' + multiply_number;
                $.ajax({
                    type: "POST",
                    url: "senddata.php",
                    data: dataString,
                    cache: false,
                    success: function(result) {
                        inverse_count = 0;
                    }
                });
                return false;
            });
        });



        function preloader() {
            setTimeout(showPage, 2500);
        }

        function showPage() {
            document.getElementById("loading").style.display = "none";
            document.getElementById("page-wrap").style.display = "block";
        }
    </script>
</body>

</html>