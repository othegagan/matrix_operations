<?php
require "db_connection.php";
session_start();

$aid = $_SESSION['admin_id'];
if ($aid == false) {
    header('Location: admin_login.php');
}
$data = mysqli_query($con, "select *from statistics ORDER BY statistics_id DESC LIMIT 1;");
$rowData = mysqli_fetch_array($data);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>ADIM | Project Matrix </title>
    <meta content="matrix home" property="og:title" />
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <link rel="stylesheet" href="style.css" />
    <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js" type="text/javascript"></script>
    <script type="text/javascript">
        WebFont.load({
            google: {
                families: [
                    "Poppins:200,300,regular,500,600,700,800",
                    "Inter:regular,500,600,700",
                ],
            },
        });
    </script>

    <style>
        .stat-card {
            padding: 15px 25px;
            margin-bottom: 25px;
            border-radius: 5px;
            overflow: hidden;
            display: flex;
            justify-content: space-around;
            box-shadow: 0 2px 10px rgb(0 0 0 / 10%);
            transition: all 0.2s;
            width: auto;
            align-items: center;
            color: honeydew;
        }

        .card-title {
            font-size: 18px;
            margin-right: 30px;
        }

        .container {
            flex-direction: row;
            flex-wrap: wrap;
            max-width: 1200px;
        }

        table {
            border-spacing: 1;
            border-collapse: collapse;
            background: white;
            border-radius: 6px;
            overflow: hidden;
            max-width: 1200px;
            width: 100%;
            margin: 0 auto;
            position: relative;
        }

        td,
        th {
            padding-left: 8px;
        }

        .tr {
            height: 60px;
            background: #606c38;
            color: honeydew;
            font-size: 16px;
        }

        tbody tr {
            height: 48px;
            border-bottom: 1px solid #E3F1D5;
        }

        td,
        th {
            text-align: left;
        }
    </style>

    <link href="images/fav-icon.svg" rel="shortcut icon" type="image/x-icon" />
</head>

<body class="body" onload="preloader()">
    <div class="loading" id="loading">
        <span>Matrix Operations</span>
    </div>

    <div class="" id="page-wrap" style="display: none">
        <!-- ------------------------------- Nav Bar -------------------------------- -->
        <div class="navbar w-nav">
            <div class="nav-container w-container">
                <img src="images/logo.svg" loading="lazy" alt="" class="image-2" /></a>
                <div class="">hi admin, <a href="admin_logout.php" class="button button-small">Logout</a></div>
            </div>

        </div>


        <div class="container">

            <!-- ----------------------------- data cards ------------------------------ -->
            <div class="stat-card green-button" style="background-color: #7678ED;">
                <p class="card-title">ADDITION</p>
                <h2>
                    <?php echo $rowData["addition"]; ?>
                </h2>
            </div>


            <div class="stat-card yellow-button" style="background-color: #A5402D;">
                <p class="card-title">SUBTRACTION</p>
                <h2>
                    <?php echo $rowData["subtraction"]; ?>
                </h2>
            </div>


            <div class="stat-card green-button" style="background-color: #7e5920;">
                <p class="card-title">MULTIPLICATION</p>
                <h2>
                    <?php echo $rowData["multiplication"]; ?>
                </h2>
            </div>


            <div class="stat-card green-button" style="background-color: #F18701;">
                <p class="card-title">TRANSPOSE</p>
                <h2> <?php echo $rowData["transpose"]; ?></h2>
            </div>


            <div class="stat-card yellow-button" style="background-color: #606c38;">
                <p class="card-title">INVERSE</p>
                <h2> <?php echo $rowData["inverse"]; ?></h2>
            </div>


            <div class="stat-card yellow-button" style="background-color: #37323e;">
                <p class="card-title">SWAP</p>
                <h2>
                    <?php echo $rowData["swap"]; ?>
                </h2>
            </div>


            <div class="stat-card green-button" style="background-color: #BA6E6E;">
                <p class="card-title">POWER OF</p>
                <h2> <?php echo $rowData["power"]; ?></h2>
            </div>


            <div class="stat-card yellow-button" style="background-color: #735290;">
                <p class="card-title">DETERMINANT</p>
                <h2> <?php echo $rowData["determinant"]; ?></h2>
            </div>
        </div>

        <br><br><br>
        <h2 style="text-align: center;">Feedback Data</h2>
        <table>
            <tr class="tr">
                <th width="5%">Sl No</th>
                <th width="15%">Name</th>
                <th width="15%">email id</th>
                <th width="50%">feedback</th>
                <th>time stamp</th>
            </tr>


            <tbody>
                <?php
                $count = 0;
                $show = mysqli_query($con, "SELECT * from feedback");
                while ($row = mysqli_fetch_array($show)) : ?>
                    <tr>
                        <td><?php
                            $count += 1;
                            echo $count;
                            ?></td>
                        <td><?php echo $row["name"]; ?></td>
                        <td><?php echo $row["email"]; ?></td>
                        <td><?php echo $row["feedback"]; ?></td>
                        <td><?php echo $row["date"]; ?></td>
                    </tr>
                <?php endwhile;
                ?>
            </tbody>
        </table>
    </div>

    <script>
        function preloader() {
            setTimeout(showPage, 100);
        }

        function showPage() {
            document.getElementById("loading").style.display = "none";
            document.getElementById("page-wrap").style.display = "block";
        }
    </script>
</body>

</html>