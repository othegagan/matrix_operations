<?php

require"db_connection.php";

session_start();

$errors = array();

// if admin click login button
if (!isset($_SESSION['admin_id'])) {
    if (isset($_POST['login'])) {
        $admin_id = mysqli_real_escape_string($con, $_POST['admin_id']);

        $password = mysqli_real_escape_string($con, $_POST['password']);

        $check_id = "SELECT * FROM admintable WHERE admin_id = '$admin_id'";

        $result = mysqli_query($con, $check_id);

        if (mysqli_num_rows($result) > 0) {
            $fetch = mysqli_fetch_assoc($result);
            $fetch_pass = $fetch['password'];
            if ($password == $fetch_pass) {
                $_SESSION['admin_id'] = $fetch['admin_id'];
                header('location: admin_index.php');
            } else {
                $errors['email'] = "Incorrect  password!";
            }
        } else {
            $errors['admin_email'] = "Incorrect Admin ID ";
        }
    }
} else {
    header("Location: admin_index.php");
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Matrix Operations | Admin Login</title>
    <link rel="stylesheet" href="style.css" />
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap');

        *,
        *:before,
        *:after {
            box-sizing: border-box;
        }

        body {
            align-items: center;
            background-image: linear-gradient(to left top, #1f1f1f, #242424, #2a292a, #302f2f, #363434);
            display: flex;
            height: 100vh;
            font-family: 'Poppins', sans-serif;
            justify-content: center;
        }

        .contact-wrapper {
            background: #fff;
            box-shadow: 3px 3px 2px rgba(0, 0, 0, 0.15);
            border-radius: 0.75em;
            text-align: center;
            padding: 2em;
            width: 25em;
        }

        .login-cta>h2 {
            color: #3e3f5e;
            font-size: 1.75rem;
            text-align: center;
        }

        form {
            margin: 2em 0;
        }

        form>.form-row {
            display: flex;
            margin: 0.75em 0;
            position: relative;
        }

        form>.form-row>span {
            background: #fff;
            color: #adafca;
            display: inline-block;
            font-weight: 400;
            left: 1em;
            padding: 0 0.5em;
            position: absolute;
            pointer-events: none;
            transform: translatey(-50%);
            top: 50%;
            transition: all 300ms ease;
            user-select: none;
        }

        form>.form-row>input,
        form>.form-row>button {
            border-radius: 0.5em;
            padding: 1em 0.5em;
            width: 100%;
        }

        form>.form-row>input {
            font-weight: bold;
            transition: 100ms ease all;
            width: 100%;
        }

        form>.form-row>input[type=text],
        form>.form-row>input[type=password] {
            border: 0.075em solid #ddd;
        }

        form>.form-row>input:valid+span {
            top: 0;
            font-size: 0.9rem;
        }

        form>.form-row>input:invalid+span {
            top: 50%;
        }

        form>.form-row>input:focus+span {
            top: 0;
        }

        form>.form-row>input:required {
            box-shadow: none;
        }

        form>.form-row>input:focus {
            border-color: #7b5dfa;
            outline: none;
        }

        form>.form-row>input:focus:invalid {
            box-shadow: none;
            top: 50%;
        }

        form>.form-row>input:focus:valid {
            top: 0;
        }

        form>.form-row>button {
            background-color: #7b5dfa;
            border: 0.1em solid #7b5dfa;
            color: #fff;
            cursor: pointer;
            font-weight: bold;
            transition: all 300ms ease;
        }

        form>.form-row>button a {
            text-decoration: none;
            color: white;
        }

        form>.form-row>button:focus {
            border: 0.1em solid #532cf8;
            outline: none;
        }

        form>.form-row>button:hover {
            background-color: #6744f9;
        }
    </style>

    <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js" type="text/javascript"></script>
    <script type="text/javascript">
        WebFont.load({
            google: {
                families: [
                    "Poppins:200,300,regular,500,600,700,800",
                    "Inter:regular,500,600,700",
                ],
            },
        });
    </script>
    <style>
        .gray{ color: #494949; letter-spacing: 1px;}
    </style>
    <link href="images/fav-icon.svg" rel="shortcut icon" type="image/x-icon" />

</head>

<body>

    <div class="contact-wrapper">
        <header class="login-cta">
            <p>Welcome back, Admin...!</p>
            <h2> Login</h2>
        </header>

        <?php
        if (count($errors) > 0) {
        ?>
            <div style="color:#ff3600;font-weight: 600;">
                <?php
                foreach ($errors as $showerror) {
                    echo $showerror;
                }
                ?>
            </div>
        <?php
        }
        ?>

        <form method="POST">
            <div class="form-row">
                <input type="text" class="gray"  name="admin_id" required  autocomplete="off">

                <span>Admin ID</span>
            </div>
            <div class="form-row">
                <input type="password" class="gray" name="password"  required autocomplete="off">
                <span>Password</span>
            </div>
            <div class="form-row"></div>
            <div class="form-row">
                <button name="login" type="submit">Login to Admin panal !</button>
            </div>
        </form>

    </div>

    <script>
        console.log(document.getElementsByName("admin_id").value);

    </script>
</body>

</html>